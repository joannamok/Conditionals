// Logical Operators

var budget = 100;
var iPhonePrice = 199.99;
var wonLottery = false;

//If iPone is less that budget or win lottery 
if(iPhonePrice < budget || wonLottery){
	console.log("We can buy the phone!");
}else{
	console.log("No phone for you !! ");
}