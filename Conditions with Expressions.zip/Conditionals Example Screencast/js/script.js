// COndition with Expression

var kidHeight = 47;
var minHeight = 48;
var sneakerlift= 2;
//if kids is over 48 inches
// +2 adds 2 inch height to kid
if(kidHeight + 2 > minHeight ){
	console.log("You can ride the coaster");

}