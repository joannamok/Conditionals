// Ternaries Operators

var gpa = 48;

//if GPA is over min 2.0 score, the students can gradute
/*if ( gpa > 2.0){
	console.log("You can graduate");
}else{
	console.log("GPA is too low!");
} */

(gpa > 2.0) ? console.log("You can gradute!") : console.log("GPA is too Low!")
