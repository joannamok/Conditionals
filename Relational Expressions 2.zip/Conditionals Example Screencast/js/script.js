// Relational Expressions

var kidHeight = 50;
var minHeight = 48;
//if kids is over 48 inches
if(kidHeight > minHeight ){
	console.log("You can ride the coaster");

}