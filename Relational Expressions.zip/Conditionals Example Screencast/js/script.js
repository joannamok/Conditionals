// Relational Expressions

var kidHeight = 50;
//if kids is over 48 inches
if(kidHeight > 48 ){
	console.log("You can ride the coaster");

}