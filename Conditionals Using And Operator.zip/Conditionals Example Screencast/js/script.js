// Logical Operators

var budget = 300;
var iPhonePrice = 199.99;
var paycheck = 200;

//If iPone is less that budget AND paycheck is over 300
if(iPhonePrice < budget && paycheck > 300){
	console.log("We can buy the phone!");
}else{
	console.log("No phone for you !! ");
}