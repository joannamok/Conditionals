// If Else

var kidHeight = 47;
var minHeight = 48;
//if kids is over 48 inches

if(kidHeight > minHeight ){
	console.log("You can ride the coaster");
}
if (kidHeight < minHeight){
	console.log("Sorry kid,You've got growing to do")
} // shows statement for kid that is not tall enough to ride