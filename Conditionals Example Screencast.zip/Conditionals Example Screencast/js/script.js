// Conditionals Practice 

var oldEnough = true;
//if child old enought,print you can ride
if(oldEnough){
// code performed if true
	console.log("You can ride the coaster!");
}
